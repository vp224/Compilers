
int printi(int num);
int prints(char * c);
int readi(int *eP);


int main(){
prints("I am vp!");
}
