int printi(int num);
int prints(char * c);
int readi(int *eP);

int main(){
	int t;
	t=100;
	int i;

	for(i=0;i<100;i++){
		i=t+i;
	}

	while(t--){
		int n,m;
		int i;
		n=10;
		for(i=0;i<n;i++)
		{
			m=m+10;
		}
	}

	if(t%100==33){
		t++;
	}
	else{
		t--;
	}
	return 0;
}